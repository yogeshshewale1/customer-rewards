
import { Component } from '@angular/core';

@Component({
  selector: 'app-admin',
  standalone: true,
  template: `
    <h2>Admin Dashboard</h2>
    <div>
      <a routerLink="/menu">Menu Management</a> |
      <a routerLink="/restaurant">Restaurant Management</a>
    </div>
  `
})
export class AdminComponent {}
