
import { Component } from '@angular/core';

@Component({
  selector: 'app-menu',
  standalone: true,
  template: `
    <h2>Menu List</h2>
    <button>Add Menu</button>
    <table border="1">
      <tr><th>Name</th><th>Price</th><th>Actions</th></tr>
      <tr><td>Pizza</td><td>250</td><td>Edit | Delete</td></tr>
    </table>
  `
})
export class MenuComponent {}
