
import { Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { MenuComponent } from './menu/menu.component';
import { RestaurantComponent } from './restaurant/restaurant.component';
import { UserComponent } from './user/user.component';

export const routes: Routes = [
  { path: 'admin', component: AdminComponent },
  { path: 'menu', component: MenuComponent },
  { path: 'restaurant', component: RestaurantComponent },
  { path: 'user', component: UserComponent },
  { path: '', redirectTo: 'admin', pathMatch: 'full' }
];
