
import { Component } from '@angular/core';

@Component({
  selector: 'app-user',
  standalone: true,
  template: `
    <h2>User Dashboard</h2>
    <p>Select Restaurant → Select Menu → Place Order</p>
    <button>Place Order</button>
    <p *ngIf="true">Order Successful!</p>
  `
})
export class UserComponent {}
