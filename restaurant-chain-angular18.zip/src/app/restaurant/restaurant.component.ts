
import { Component } from '@angular/core';

@Component({
  selector: 'app-restaurant',
  standalone: true,
  template: `
    <h2>Restaurant List</h2>
    <button>Add Restaurant</button>
    <table border="1">
      <tr><th>Name</th><th>Actions</th></tr>
      <tr><td>Food Hub</td><td>Edit | Delete</td></tr>
    </table>
  `
})
export class RestaurantComponent {}
