// ES6 + TypeScript Assignment Demo

// 1. Constant
const PI: number = 3.14;
console.log("PI:", PI);

// 2. Block scope
if (true) {
  let msg: string = "Hello TypeScript";
  console.log(msg);
}

// 3. Object with methods
const order = {
  id: 1,
  title: "Laptop",
  price: 50000,
  printOrder() {
    console.log(this.id, this.title);
  },
  getPrice() {
    return this.price;
  }
};

const orderCopy = Object.assign({}, order);
orderCopy.printOrder();

// 4. Arrow function
const names: string[] = ["Tom", "Ivan", "Jerry"];
const nameObjects = names.map(name => ({ name, length: name.length }));
console.log(nameObjects);

// 5. Default, Rest, Spread
function add(a: number = 0, b: number = 0): number {
  return a + b;
}

function userFriends(user: string, ...friends: string[]) {
  console.log(user, friends);
}

function printCapitalNames(...names: string[]) {
  console.log(names.map(n => n.toUpperCase()));
}

printCapitalNames(...names);

// 6. Template literal
const ticket = `Laptop Issue:
User: Yogesh
Model: Dell
Desk: D-204`;

console.log(ticket);

// 7. Destructuring
const arr = [10, 20, 30, 40];
const [, , third] = arr;
console.log(third);

const org = { name: "ABC", address: { pin: 411001 } };
const { address: { pin } } = org;
console.log(pin);

// 8. Classes
class Account {
  constructor(public id: number, public name: string, public balance: number) {}
}

class SavingAccount extends Account {
  constructor(id: number, name: string, balance: number, public interest: number) {
    super(id, name, balance);
  }
}

class CurrentAccount extends Account {
  constructor(id: number, name: string, balance: number, public cashCredit: number) {
    super(id, name, balance);
  }
}

const accounts: Account[] = [
  new SavingAccount(1, "A", 10000, 5),
  new CurrentAccount(2, "B", 20000, 1000)
];

const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
console.log("Total Balance:", totalBalance);
