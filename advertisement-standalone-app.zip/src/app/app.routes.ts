
import { Routes } from '@angular/router';
import { AdvertisementTableComponent } from './components/advertisement-table/advertisement-table.component';
import { EditProductComponent } from './components/edit-product/edit-product.component';

export const routes: Routes = [
  { path: '', component: AdvertisementTableComponent },
  { path: 'edit/:id', component: EditProductComponent }
];
