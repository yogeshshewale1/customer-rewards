
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AdvertisementFormComponent } from './components/advertisement-form/advertisement-form.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, AdvertisementFormComponent],
  template: \`
    <h2>Advertisement App</h2>
    <app-advertisement-form></app-advertisement-form>
    <router-outlet></router-outlet>
  \`
})
export class AppComponent {}
