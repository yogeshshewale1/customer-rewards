
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AdvertisementService } from '../../services/advertisement.service';
import { SearchPipe } from '../../pipes/search.pipe';

@Component({
  standalone:true,
  imports:[FormsModule,SearchPipe],
  template:\`
    <input [(ngModel)]="search"/>
    <table>
      <tr *ngFor="let ad of service.getAll() | search:search">
        <td>{{ad.title}}</td>
        <td>{{ad.name}}</td>
        <td>
          <a (click)="edit(ad.id)">EDIT</a> |
          <a (click)="del(ad.id)">DELETE</a>
        </td>
      </tr>
    </table>
  \`
})
export class AdvertisementTableComponent {
  search='';
  constructor(public service:AdvertisementService, private router:Router){}
  del(id:number){ this.service.delete(id); }
  edit(id:number){ this.router.navigate(['/edit',id]); }
}
