
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AdvertisementService } from '../../services/advertisement.service';

@Component({
  standalone:true,
  imports:[FormsModule],
  template:\`
    <input [(ngModel)]="model.title"/>
    <input [(ngModel)]="model.name"/>
    <button (click)="update()">UPDATE</button>
    <button (click)="cancel()">CANCEL</button>
  \`
})
export class EditProductComponent {
  model:any;
  constructor(route:ActivatedRoute, private service:AdvertisementService, private router:Router){
    const id=Number(route.snapshot.paramMap.get('id'));
    this.model={...this.service.getById(id)};
  }
  update(){ this.service.update(this.model); this.router.navigate(['/']); }
  cancel(){ this.router.navigate(['/']); }
}
