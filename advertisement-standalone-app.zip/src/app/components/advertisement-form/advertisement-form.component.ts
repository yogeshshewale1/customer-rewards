
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AdvertisementService } from '../../services/advertisement.service';

@Component({
  selector: 'app-advertisement-form',
  standalone: true,
  imports: [FormsModule],
  template: \`
    <input [(ngModel)]="model.title" placeholder="Title"/>
    <input [(ngModel)]="model.name"/>
    <select [(ngModel)]="model.category">
      <option *ngFor="let c of categories">{{c}}</option>
    </select>
    <button (click)="add()" [disabled]="!model.title">Add</button>
  \`
})
export class AdvertisementFormComponent {
  categories=['Furniture','Hardware','Mobile'];
  model:any={name:'Yogesh Shewale'};
  constructor(private service:AdvertisementService){}
  add(){ this.service.add({...this.model}); this.model={name:'Yogesh Shewale'}; }
}
