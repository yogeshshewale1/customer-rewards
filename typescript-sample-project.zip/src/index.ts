// 1. Promises using Promise.all
const promiseX = new Promise<number>((resolve) => {
  setTimeout(() => resolve(10), 500);
});

const promiseY = new Promise<number>((resolve) => {
  setTimeout(() => resolve(20), 500);
});

Promise.all([promiseX, promiseY]).then(([x, y]) => {
  console.log("Sum of x and y:", x + y);
});

// 2. TypeScript Classes & Inheritance
class Account {
  constructor(
    public id: number,
    public name: string,
    public balance: number
  ) {}
}

class SavingAccount extends Account {
  constructor(
    id: number,
    name: string,
    balance: number,
    public interest: number
  ) {
    super(id, name, balance);
  }
}

class CurrentAccount extends Account {
  constructor(
    id: number,
    name: string,
    balance: number,
    public cash_credit: number
  ) {
    super(id, name, balance);
  }
}

const accounts: Account[] = [
  new SavingAccount(1, "Yogesh", 5000, 4),
  new SavingAccount(2, "Amit", 7000, 5),
  new CurrentAccount(3, "Ravi", 10000, 2000),
  new CurrentAccount(4, "Neha", 8000, 1500)
];

const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
console.log("Total balance in bank:", totalBalance);

// 3. Interfaces
interface Printable {
  print(): void;
}

class Circle implements Printable {
  constructor(public radius: number) {}

  print(): void {
    console.log("Circle radius:", this.radius);
  }
}

class Employee implements Printable {
  constructor(public id: number, public name: string) {}

  print(): void {
    console.log(`Employee Id: ${this.id}, Name: ${this.name}`);
  }
}

function printAll(objects: Printable[]): void {
  objects.forEach(obj => obj.print());
}

const printableObjects: Printable[] = [
  new Circle(5),
  new Employee(101, "Rahul")
];

printAll(printableObjects);