function ValidateNonEmpty(inputField, errorField) {
  if (inputField.value.trim() === "") {
    errorField.innerHTML = "Field cannot be empty";
    return false;
  }
  errorField.innerHTML = "";
  return true;
}

function ValidateByPattern(inputField, pattern, errorMessage, errorField) {
  if (!pattern.test(inputField.value)) {
    errorField.innerHTML = errorMessage;
    return false;
  }
  errorField.innerHTML = "";
  return true;
}

function ValidateLength(inputField, minChar, maxChar, errorMessage, errorField) {
  if (inputField.value.length < minChar || inputField.value.length > maxChar) {
    errorField.innerHTML = errorMessage;
    return false;
  }
  errorField.innerHTML = "";
  return true;
}

function validate() {
  let valid = true;

  let name = document.getElementById("name");
  let dob = document.getElementById("dob");
  let phone = document.getElementById("phone");
  let email = document.getElementById("email");
  let country = document.getElementById("country");
  let city = document.getElementById("city");

  valid &= ValidateNonEmpty(name, nameErr);
  valid &= ValidateLength(name, 3, 10, "Name must be 3-10 chars", nameErr);

  let dobPattern = /^\d{2}\/\d{2}\/(\d{2}|\d{4})$/;
  valid &= ValidateByPattern(dob, dobPattern, "Invalid DOB format", dobErr);

  let phonePattern = /^\d{3}-\d{4}-\d{4}$/;
  valid &= ValidateByPattern(phone, phonePattern, "Invalid phone format", phoneErr);

  let emailPattern = /^[a-zA-Z0-9._]+@yahoo\.(com|in|co\.in)$/;
  valid &= ValidateByPattern(email, emailPattern, "Invalid email format", emailErr);

  if (country.value === "") {
    countryErr.innerHTML = "Select country";
    valid = false;
  } else countryErr.innerHTML = "";

  if (city.value === "") {
    cityErr.innerHTML = "Select city";
    valid = false;
  } else cityErr.innerHTML = "";

  if (valid) alert("Validation Successful");
  return false;
}