
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AdvertisementFormComponent } from './components/advertisement-form/advertisement-form.component';
import { AdvertisementTableComponent } from './components/advertisement-table/advertisement-table.component';
import { EditProductComponent } from './components/edit-product/edit-product.component';
import { SearchPipe } from './pipes/search.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AdvertisementFormComponent,
    AdvertisementTableComponent,
    EditProductComponent,
    SearchPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: AdvertisementTableComponent },
      { path: 'edit/:id', component: EditProductComponent }
    ])
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
