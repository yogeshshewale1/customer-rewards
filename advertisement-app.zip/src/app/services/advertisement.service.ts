
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AdvertisementService {
  private adverts: any[] = [
    { id: 1, title: 'Sofa', name: 'Yogesh Shewale', category: 'Furniture', description: 'Comfortable sofa' }
  ];

  getAll() { return this.adverts; }
  getById(id: number) { return this.adverts.find(a => a.id === id); }
  add(ad: any) { ad.id = Date.now(); this.adverts.push(ad); }
  delete(id: number) { this.adverts = this.adverts.filter(a => a.id !== id); }
  update(ad: any) {
    const i = this.adverts.findIndex(x => x.id === ad.id);
    if (i > -1) this.adverts[i] = ad;
  }
}
