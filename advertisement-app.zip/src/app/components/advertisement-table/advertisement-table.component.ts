
import { Component } from '@angular/core';
import { AdvertisementService } from '../../services/advertisement.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-advertisement-table',
  template: `
    <input [(ngModel)]="search" placeholder="Search"/>
    <table border="1">
      <tr>
        <th>Title</th><th>Name</th><th>Category</th><th>Actions</th>
      </tr>
      <tr *ngFor="let ad of service.getAll() | search:search">
        <td>{{ad.title}}</td>
        <td>{{ad.name}}</td>
        <td>{{ad.category}}</td>
        <td>
          <a (click)="edit(ad.id)">EDIT</a> |
          <a (click)="delete(ad.id)">DELETE</a>
        </td>
      </tr>
    </table>
  `
})
export class AdvertisementTableComponent {
  search = '';
  constructor(public service: AdvertisementService, private router: Router) {}
  delete(id:number){ this.service.delete(id); }
  edit(id:number){ this.router.navigate(['/edit', id]); }
}
