
import { Component } from '@angular/core';
import { AdvertisementService } from '../../services/advertisement.service';

@Component({
  selector: 'app-advertisement-form',
  template: `
    <h3>Add Advertisement</h3>
    <input [(ngModel)]="model.title" placeholder="Title" required />
    <input [(ngModel)]="model.name" placeholder="Name" />
    <select [(ngModel)]="model.category">
      <option *ngFor="let c of categories">{{c}}</option>
    </select>
    <textarea [(ngModel)]="model.description" placeholder="Description"></textarea>
    <button (click)="submit()" [disabled]="!model.title">Add</button>
  `
})
export class AdvertisementFormComponent {
  categories = ['Furniture', 'Hardware', 'Mobile'];
  model: any = { name: 'Yogesh Shewale' };

  constructor(private service: AdvertisementService) {}
  submit() { this.service.add({ ...this.model }); this.model = { name: 'Yogesh Shewale' }; }
}
