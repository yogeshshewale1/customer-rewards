
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name:'search'})
export class SearchPipe implements PipeTransform{
  transform(items:any[], text:string){
    if(!text) return items;
    return items.filter(i =>
      i.title.toLowerCase().includes(text.toLowerCase()) ||
      i.name.toLowerCase().includes(text.toLowerCase())
    );
  }
}
