
// ===============================
// 1. Fibonacci using Symbol.iterator
// ===============================
class Fibonacci {
  private previousNo: number = 0;
  private currentNo: number = 1;

  next(): number {
    const nextVal = this.previousNo + this.currentNo;
    this.previousNo = this.currentNo;
    this.currentNo = nextVal;
    return this.previousNo;
  }
}

const fib = new Fibonacci();
console.log("Fibonacci:", fib.next(), fib.next(), fib.next(), fib.next());

// ===============================
// 2. Iterator – Armstrong Numbers
// ===============================
class ArmstrongIterator {
  private current: number = 0;

  private isArmstrong(num: number): boolean {
    const digits = num.toString().split('').map(Number);
    const power = digits.length;
    return digits.reduce((s, d) => s + Math.pow(d, power), 0) === num;
  }

  getNextArmstrong(): number {
    while (true) {
      this.current++;
      if (this.isArmstrong(this.current)) {
        return this.current;
      }
    }
  }
}

const armIter = new ArmstrongIterator();
console.log("Armstrong:", armIter.getNextArmstrong(), armIter.getNextArmstrong());

// ===============================
// 3. Generator – Armstrong Numbers
// ===============================
function* armstrongGenerator() {
  let num = 0;

  const isArmstrong = (n: number): boolean => {
    const digits = n.toString().split('').map(Number);
    const power = digits.length;
    return digits.reduce((s, d) => s + Math.pow(d, power), 0) === n;
  };

  while (true) {
    if (num > 1000) {
      throw new Error("Armstrong number exceeded 1000");
    }
    if (isArmstrong(num)) {
      yield num;
    }
    num++;
  }
}

let gen = armstrongGenerator();
console.log("Generator Armstrong:", gen.next().value, gen.next().value);

gen = armstrongGenerator(); // reset
console.log("After reset:", gen.next().value);

// ===============================
// 4. Collections – Chat Application
// ===============================
type Message = string;

class ChatRoom {
  users: Set<string> = new Set();
  messages: Map<string, Message[]> = new Map();
}

const chatRooms: Map<string, ChatRoom> = new Map();

// Create chat rooms
chatRooms.set("Room1", new ChatRoom());
chatRooms.set("Room2", new ChatRoom());

// Add users & messages
chatRooms.get("Room1")?.users.add("Alice");
chatRooms.get("Room1")?.users.add("Bob");
chatRooms.get("Room1")?.users.add("Charlie");

chatRooms.get("Room1")?.messages.set("Alice", ["Hi", "How are you?"]);
chatRooms.get("Room1")?.messages.set("Bob", ["Hello"]);
chatRooms.get("Room1")?.messages.set("Charlie", ["Good morning"]);

// Functions
function getUsers(roomName: string): string[] {
  return Array.from(chatRooms.get(roomName)?.users || []);
}

function getMessages(roomName: string): Message[] {
  const room = chatRooms.get(roomName);
  if (!room) return [];
  return Array.from(room.messages.values()).flat();
}

console.log("Users in Room1:", getUsers("Room1"));
console.log("Messages in Room1:", getMessages("Room1"));
